import React, { createContext, useState, useContext, useEffect, useCallback } from 'react';

export type Language = 'pt' | 'en' | 'fr' | 'es';

export const LANGUAGES: Record<Language, string> = {
  pt: 'Português',
  en: 'English',
  fr: 'Français',
  es: 'Español'
};

interface I18nContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string, options?: { [key: string]: string | number }) => string;
}

const I18nContext = createContext<I18nContextType | undefined>(undefined);

const getNestedTranslation = (obj: any, key: string): string | undefined => {
  return key.split('.').reduce((o, i) => (o ? o[i] : undefined), obj);
};

export const I18nProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [translations, setTranslations] = useState<Record<string, any> | null>(null);
  const [loading, setLoading] = useState(true);
  const [language, setLanguageState] = useState<Language>(
    () => (localStorage.getItem('cidadao_alerta_lang') as Language) || 'pt'
  );

  const setLanguage = (lang: Language) => {
    localStorage.setItem('cidadao_alerta_lang', lang);
    setLanguageState(lang);
  };

  useEffect(() => {
    const loadTranslations = async () => {
      setLoading(true);
      try {
        const responses = await Promise.all([
          fetch('./locales/pt.json'),
          fetch('./locales/en.json'),
          fetch('./locales/fr.json'),
          fetch('./locales/es.json'),
        ]);
        const [pt, en, fr, es] = await Promise.all(responses.map(r => r.ok ? r.json() : {}));
        setTranslations({ pt, en, fr, es });
      } catch (error) {
        console.error("Failed to load translations.", error);
      } finally {
        setLoading(false);
      }
    };
    loadTranslations();
  }, []);

  useEffect(() => {
    document.documentElement.lang = language;
  }, [language]);

  const t = useCallback((key: string, options?: { [key: string]: string | number }): string => {
    if (!translations || !translations[language]) {
      return key;
    }

    let translation = getNestedTranslation(translations[language], key);
    
    if (!translation) {
      console.warn(`Translation key not found: ${key}`);
      return key;
    }
    
    if (options) {
      Object.keys(options).forEach(optionKey => {
        translation = translation!.replace(`{{${optionKey}}}`, String(options[optionKey]));
      });
    }

    return translation;
  }, [language, translations]);

  if (loading || !translations) {
    return (
      <div className="fixed inset-0 z-[100] flex items-center justify-center bg-white">
        <div className="w-12 h-12 border-4 border-slate-200 border-t-blue-600 rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <I18nContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </I18nContext.Provider>
  );
};

export const useI18n = () => {
  const context = useContext(I18nContext);
  if (!context) {
    throw new Error('useI18n must be used within an I18nProvider');
  }
  return context;
};
