import { jsPDF } from 'jspdf';
import { Report } from '../types.ts';

// Vamos manter as fontes padrão para garantir a compatibilidade. 'helvetica' é uma escolha segura.

export const generateReportPDF = async (report: Report, t: (key: string, options?: { [key: string]: string | number }) => string) => {
  const doc = new jsPDF();
  const pageHeight = doc.internal.pageSize.getHeight();
  const pageWidth = doc.internal.pageSize.getWidth();
  let y = 20; // Posição y atual

  // --- Cabeçalho ---
  doc.setFontSize(22);
  doc.setFont('helvetica', 'bold');
  doc.text(t('appName'), pageWidth / 2, y, { align: 'center' });
  y += 10;
  doc.setFontSize(14);
  doc.setFont('helvetica', 'normal');
  doc.text(t('pdf.title'), pageWidth / 2, y, { align: 'center' });
  y += 15;

  // --- Detalhes da Denúncia ---
  const addDetail = (label: string, value: string) => {
    if (y > pageHeight - 20) {
      doc.addPage();
      y = 20;
    }
    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    doc.text(label, 15, y);
    doc.setFont('helvetica', 'normal');
    doc.text(value, 55, y);
    y += 7;
  };

  addDetail(`${t('pdf.reportId')}:`, report.id);
  addDetail(`${t('pdf.submissionDate')}:`, new Date(report.timestamp).toLocaleString());
  addDetail(`${t('pdf.agency')}:`, report.agency);
  addDetail(`${t('pdf.category')}:`, report.type);
  addDetail(`${t('pdf.location')}:`, report.location.address);
  y += 5;

  // --- Descrição ---
  doc.setFontSize(10);
  doc.setFont('helvetica', 'bold');
  doc.text(`${t('pdf.description')}:`, 15, y);
  y += 7;

  doc.setFont('helvetica', 'normal');
  const descriptionLines = doc.splitTextToSize(report.description, pageWidth - 30); // Margem de 15 de cada lado
  
  for (const line of descriptionLines) {
    if (y > pageHeight - 20) {
        doc.addPage();
        y = 20;
    }
    doc.text(line, 15, y);
    y += 5;
  }
  y += 10;
  
  // --- Evidência ---
  if (report.evidence) {
    try {
        if (y > pageHeight - 80) { // Verifica se há espaço para o cabeçalho e parte da imagem
            doc.addPage();
            y = 20;
        }
        doc.setFontSize(10);
        doc.setFont('helvetica', 'bold');
        doc.text(`${t('pdf.evidence')}:`, 15, y);
        y += 7;
        
        const img = new Image();
        img.src = report.evidence;
        await new Promise(resolve => {
            img.onload = resolve;
        });

        const imgProps = doc.getImageProperties(report.evidence);
        const imgWidth = pageWidth - 30; // Largura máxima
        const imgHeight = (imgProps.height * imgWidth) / imgProps.width;
        
        if (y + imgHeight > pageHeight - 20) {
            doc.addPage();
            y = 20;
        }

        doc.addImage(report.evidence, 'JPEG', 15, y, imgWidth, imgHeight);
    } catch (e) {
        console.error("Erro ao adicionar imagem ao PDF", e);
        if (y > pageHeight - 20) {
            doc.addPage();
            y = 20;
        }
        doc.setFont('helvetica', 'italic');
        doc.text("Não foi possível carregar a imagem da evidência.", 15, y);
    }
  }


  // --- Rodapé em todas as páginas ---
  const pageCount = doc.internal.pages.length;
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFontSize(8);
    doc.setTextColor(150);
    doc.text(
      `${t('pdf.footer')} | ${new Date().toLocaleDateString()}`,
      pageWidth / 2,
      pageHeight - 10,
      { align: 'center' }
    );
  }

  // --- Salvar ---
  doc.save(`denuncia-CidadaoAlerta-${report.id}.pdf`);
};
