
// NOTA DE SEGURANÇA: Esta é uma função de ofuscação simples, não uma cifragem criptográfica forte.
// Serve para impedir a leitura casual de dados no localStorage. Numa aplicação de produção em larga escala,
// deveria ser utilizada a Web Crypto API com uma gestão de chaves mais robusta.

// Uma chave simples de ofuscação.
const OBFUSCATION_KEY = 'CidadaoAlertaSecretKeyForLocalStorage';

const keyCharAt = (key: string, i: number) => key.charCodeAt(i % key.length);

/**
 * Ofusca uma string de dados para que não seja legível em texto simples.
 * @param data A string de dados (ex: JSON stringified).
 * @returns Uma string codificada em base64 representando os dados ofuscados.
 */
export const obfuscateData = (data: string): string => {
  try {
    const obfuscated = data.split('').map((char, i) => {
      return String.fromCharCode(char.charCodeAt(0) + keyCharAt(OBFUSCATION_KEY, i));
    }).join('');
    // btoa para garantir que a string resultante é segura para armazenamento.
    return btoa(encodeURIComponent(obfuscated));
  } catch (e) {
    console.error("A ofuscação falhou", e);
    return btoa(encodeURIComponent(data)); // Fallback para base64 puro em caso de erro.
  }
};

/**
 * De-ofusca uma string de dados que foi previamente ofuscada.
 * @param obfuscatedData A string codificada em base64.
 * @returns A string de dados original.
 */
export const deobfuscateData = (obfuscatedData: string): string => {
  try {
    const decoded = decodeURIComponent(atob(obfuscatedData));
    return decoded.split('').map((char, i) => {
      return String.fromCharCode(char.charCodeAt(0) - keyCharAt(OBFUSCATION_KEY, i));
    }).join('');
  } catch (e) {
    console.error("A de-ofuscação falhou", e);
    // Tenta descodificar como base64 puro se a de-ofuscação falhar.
    try {
      return decodeURIComponent(atob(obfuscatedData));
    } catch (finalError) {
      console.error("A descodificação final falhou", finalError);
      return ''; // Retorna uma string vazia se tudo falhar.
    }
  }
};
