
/**
 * Comprime uma imagem representada por uma string base64.
 * @param base64Str A string base64 da imagem original.
 * @param quality A qualidade da imagem de saída (0 a 1).
 * @param maxWidth A largura máxima da imagem de saída.
 * @returns Uma Promise que resolve com a string base64 da imagem comprimida.
 */
export const compressImage = (base64Str: string, quality = 0.7, maxWidth = 800): Promise<string> => {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.src = base64Str;
    img.onload = () => {
      let { width, height } = img;

      // Se a imagem for maior que a largura máxima, redimensiona
      if (width > maxWidth) {
        const ratio = maxWidth / width;
        width = maxWidth;
        height = height * ratio;
      }

      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;

      const ctx = canvas.getContext('2d');
      if (!ctx) {
        return reject(new Error('Não foi possível obter o contexto 2D do canvas.'));
      }
      
      ctx.drawImage(img, 0, 0, width, height);

      // Converte para JPEG com a qualidade especificada
      const compressedBase64 = canvas.toDataURL('image/jpeg', quality);
      resolve(compressedBase64);
    };
    img.onerror = (error) => {
      console.error("Erro ao carregar a imagem para compressão:", error);
      reject(new Error("Falha ao carregar a imagem para o processo de compressão."));
    };
  });
};
