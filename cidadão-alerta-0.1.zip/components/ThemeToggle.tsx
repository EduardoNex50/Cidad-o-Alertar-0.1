import React from 'react';
import { useTheme } from '../contexts/ThemeContext.tsx';
import { useI18n } from '../i18n/index.tsx';

export const ThemeToggle: React.FC = () => {
  const { theme, toggleTheme } = useTheme();
  const { t } = useI18n();

  return (
    <button
      onClick={toggleTheme}
      className="w-14 h-8 rounded-full bg-slate-200 dark:bg-slate-700 flex items-center p-1 transition-colors duration-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
      aria-label={t('profile.theme.toggle', { theme: theme === 'light' ? 'dark' : 'light' })}
    >
      <div
        className={`w-6 h-6 rounded-full bg-white shadow-md transform transition-transform duration-300 flex items-center justify-center ${
          theme === 'dark' ? 'translate-x-6' : 'translate-x-0'
        }`}
      >
        {theme === 'light' ? (
          <i className="fa-solid fa-sun text-yellow-500 text-xs"></i>
        ) : (
          <i className="fa-solid fa-moon text-blue-400 text-xs"></i>
        )}
      </div>
    </button>
  );
};
