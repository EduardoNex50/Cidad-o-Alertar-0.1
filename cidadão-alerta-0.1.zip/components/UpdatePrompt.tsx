
import React from 'react';
import { useI18n } from '../i18n/index.tsx';

interface UpdatePromptProps {
  onUpdate: () => void;
}

export const UpdatePrompt: React.FC<UpdatePromptProps> = ({ onUpdate }) => {
  const { t } = useI18n();
  return (
    <div className="fixed bottom-24 left-6 right-6 sm:left-auto sm:bottom-6 sm:right-6 z-[60] animate-in slide-in-from-bottom-10">
      <div className="bg-slate-800 text-white p-4 rounded-2xl shadow-2xl flex items-center justify-between">
        <div>
          <p className="font-bold">{t('pwa.updateTitle')}</p>
          <p className="text-xs text-slate-300">{t('pwa.updateMessage')}</p>
        </div>
        <button
          onClick={onUpdate}
          className="py-2 px-4 bg-indigo-500 text-white rounded-xl font-bold text-sm hover:bg-indigo-600 transition-colors shrink-0 ml-4"
        >
          {t('pwa.updateButton')}
        </button>
      </div>
    </div>
  );
};