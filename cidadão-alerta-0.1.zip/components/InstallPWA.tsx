import React from 'react';
import { useI18n } from '../i18n/index.tsx';

interface InstallPWAProps {
  onInstall: () => void;
  onClose: () => void;
}

export const InstallPWA: React.FC<InstallPWAProps> = ({ onInstall, onClose }) => {
  const { t } = useI18n();
  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
      <div className="bg-white dark:bg-slate-800 w-full max-w-sm rounded-3xl shadow-2xl p-8 text-center transform animate-in slide-in-from-bottom-10">
        <div className="w-20 h-20 mx-auto bg-blue-100 dark:bg-blue-900/50 rounded-full flex items-center justify-center border-8 border-blue-50 dark:border-blue-800/30 mb-6">
            <i className="fa-solid fa-mobile-screen-button text-4xl text-blue-600 dark:text-blue-400"></i>
        </div>
        
        <h2 className="text-2xl font-black text-slate-800 dark:text-slate-100 mb-2">{t('pwa.installTitle')}</h2>
        <p className="text-slate-600 dark:text-slate-300 mb-8">
          {t('pwa.installMessage')}
        </p>

        <div className="space-y-3">
            <button
                onClick={onInstall}
                className="w-full py-4 px-4 bg-blue-600 text-white rounded-xl font-bold text-lg shadow-lg shadow-blue-200 active:scale-95 transition-all"
            >
                <i className="fa-solid fa-download mr-2"></i>
                {t('pwa.installButton')}
            </button>
            <button
                onClick={onClose}
                className="w-full py-3 px-4 rounded-xl font-bold text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
            >
                {t('pwa.laterButton')}
            </button>
        </div>
      </div>
    </div>
  );
};
