import React from 'react';
import { Report } from '../types.ts';
import { useI18n } from '../i18n/index.tsx';

interface ReportItemProps {
  report: Report;
  onClick: () => void;
}

const ReportItemComponent: React.FC<ReportItemProps> = ({ report, onClick }) => {
  const { t } = useI18n();

  const getStatusInfo = (status: Report['status']) => {
      switch (status) {
          case 'Pendente Sincronização':
              return {
                  text: t('history.status.syncing'),
                  color: 'bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-200',
                  icon: <i className="fa-solid fa-cloud-arrow-up mr-1 animate-pulse"></i>
              };
          case 'Pendente':
              return {
                  text: t('history.status.pending'),
                  color: 'bg-amber-100 dark:bg-amber-900/50 text-amber-700 dark:text-amber-200',
                  icon: null
              };
          case 'Resolvido':
              return {
                  text: t('history.status.resolved'),
                  color: 'bg-emerald-100 dark:bg-emerald-900/50 text-emerald-700 dark:text-emerald-200',
                  icon: null
              };
          default:
               return {
                  text: status,
                  color: 'bg-blue-100 dark:bg-blue-900/50 text-blue-700 dark:text-blue-200',
                  icon: null
              };
      }
  };

  const statusInfo = getStatusInfo(report.status);

  return (
    <button onClick={onClick} className="w-full bg-white dark:bg-slate-800 p-4 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm text-left hover:border-slate-300 dark:hover:border-slate-600 transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500">
      <div className="flex justify-between items-start mb-2">
        <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider flex items-center ${statusInfo.color}`}>
          {statusInfo.icon}{statusInfo.text}
        </span>
        <span className="text-xs text-slate-400 dark:text-slate-500">{new Date(report.timestamp).toLocaleDateString()}</span>
      </div>
      <h4 className="font-bold text-slate-800 dark:text-slate-100">{report.type}</h4>
      <p className="text-sm text-slate-600 dark:text-slate-400 mt-1 line-clamp-2">{report.description}</p>

      <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-700 flex items-center justify-between text-xs">
        <span className="font-bold text-slate-400 dark:text-slate-500 uppercase">
          <i className="fa-solid fa-building mr-2"></i> {report.agency}
        </span>
        <div className="font-bold text-blue-600 dark:text-blue-400">
          {t('buttons.viewMore')}
          <i className="fa-solid fa-chevron-right ml-2"></i>
        </div>
      </div>
    </button>
  );
};

export const ReportItem = React.memo(ReportItemComponent);
