import React from 'react';
import { AgencyInfo } from '../types.ts';

interface AgencyCardProps {
  agency: AgencyInfo;
  onClick: (agency: AgencyInfo) => void;
}

const AgencyCardComponent: React.FC<AgencyCardProps> = ({ agency, onClick }) => {
  return (
    <button
      onClick={() => onClick(agency)}
      className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 flex items-center space-x-4 hover:border-slate-400 dark:hover:border-slate-500 transition-colors text-left w-full"
    >
      <div className={`${agency.color} w-12 h-12 rounded-lg flex items-center justify-center text-white shrink-0`}>
        <i className={`fa-solid ${agency.icon} text-xl`}></i>
      </div>
      <div>
        <h3 className="font-bold text-slate-800 dark:text-slate-100">{agency.id}</h3>
        <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-1">{agency.description}</p>
      </div>
    </button>
  );
};

export const AgencyCard = React.memo(AgencyCardComponent);
