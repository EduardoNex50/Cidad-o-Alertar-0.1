import React, { useState, useRef } from 'react';
import { AgencyType, Report } from '../types.ts';
import { REPORT_CATEGORIES } from '../constants.tsx';
import { classifyIncident } from '../services/geminiService.ts';
import { compressImage } from '../utils/imageOptimizer.ts';
import { useI18n } from '../i18n/index.tsx';


interface ReportFormProps {
  agency: AgencyType;
  onClose: () => void;
  onSubmit: (report: Partial<Report>) => void;
}

export const ReportForm: React.FC<ReportFormProps> = ({ agency, onClose, onSubmit }) => {
  const { t, language } = useI18n();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [category, setCategory] = useState('');
  const [description, setDescription] = useState('');
  const [address, setAddress] = useState('');
  const [image, setImage] = useState<string | null>(null);
  const [aiAnalysis, setAiAnalysis] = useState<any>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isCameraOpen, setIsCameraOpen] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const processAndSetImage = async (base64: string) => {
    try {
        setLoading(true);
        const compressed = await compressImage(base64);
        setImage(compressed);
    } catch (error) {
        console.error("Falha ao comprimir imagem:", error);
        setImage(base64); // Fallback para a imagem original
    } finally {
        setLoading(false);
    }
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        processAndSetImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleOpenCamera = async () => {
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true });
        streamRef.current = stream;
        setIsCameraOpen(true);
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
      } catch (err) {
        console.error("Erro ao aceder à câmara: ", err);
        alert(t('errors.cameraAccess'));
      }
    }
  };

  const handleCloseCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
    }
    setIsCameraOpen(false);
  };

  const handleCapturePhoto = () => {
    if (videoRef.current) {
      const canvas = document.createElement('canvas');
      canvas.width = videoRef.current.videoWidth;
      canvas.height = videoRef.current.videoHeight;
      const context = canvas.getContext('2d');
      if (context) {
        context.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL('image/jpeg');
        processAndSetImage(dataUrl);
      }
      handleCloseCamera();
    }
  };


  const handleNext = async () => {
    if (step === 1 && description.length > 10) {
      setLoading(true);
      const analysis = await classifyIncident(description, language);
      setAiAnalysis(analysis);
      setLoading(false);
      setStep(2);
    } else if (step === 2) {
      setStep(3);
    }
  };

  const handleSubmit = () => {
    onSubmit({
      agency,
      type: category,
      description,
      location: { address },
      evidence: image || undefined
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className="bg-white dark:bg-slate-800 w-full max-w-lg rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        <div className="p-4 border-b border-slate-200 dark:border-slate-700 flex justify-between items-center bg-slate-50 dark:bg-slate-800">
          <h2 className="font-bold text-lg text-slate-900 dark:text-slate-100">{t('reportForm.title', { agency })}</h2>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-300">
            <i className="fa-solid fa-xmark text-xl"></i>
          </button>
        </div>

        <div className="p-6 overflow-y-auto">
          {step === 1 && (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-semibold mb-2 text-slate-800 dark:text-slate-200">{t('reportForm.categoryLabel')}</label>
                <select 
                  className="w-full p-3 border border-slate-300 dark:border-slate-600 rounded-xl bg-slate-50 dark:bg-slate-700 text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-blue-500"
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                >
                  <option value="">{t('reportForm.categoryPlaceholder')}</option>
                  {REPORT_CATEGORIES[agency].map(catKey => {
                      const translatedCat = t(`reportCategories.${agency}.${catKey}`);
                      return (
                        <option key={catKey} value={translatedCat}>{translatedCat}</option>
                      );
                  })}
                </select>
              </div>
              <div>
                <label className="block text-sm font-semibold mb-2 text-slate-800 dark:text-slate-200">{t('reportForm.descriptionLabel')}</label>
                <textarea 
                  className="w-full p-3 border border-slate-300 dark:border-slate-600 rounded-xl bg-slate-50 dark:bg-slate-700 h-32 text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-blue-500"
                  placeholder={t('reportForm.descriptionPlaceholder')}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                ></textarea>
                <p className="text-xs text-slate-400 dark:text-slate-500 mt-1">{t('reportForm.descriptionHint')}</p>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4">
               {aiAnalysis && (
                <div className="bg-blue-50 dark:bg-blue-900/50 p-4 rounded-xl border border-blue-100 dark:border-blue-800 flex items-start space-x-3">
                  <i className="fa-solid fa-robot text-blue-500 mt-1"></i>
                  <div>
                    <h4 className="text-sm font-bold text-blue-800 dark:text-blue-200">{t('reportForm.aiAnalysis.title')}</h4>
                    <p className="text-sm text-blue-700 dark:text-blue-300">{aiAnalysis.conselho_imediato}</p>
                    <div className="mt-2 flex gap-2">
                      <span className="px-2 py-0.5 bg-blue-200 dark:bg-blue-800 text-blue-800 dark:text-blue-100 rounded text-[10px] font-bold uppercase tracking-wider">{t('reportForm.aiAnalysis.urgency', { level: aiAnalysis.urgencia })}</span>
                    </div>
                  </div>
                </div>
              )}
              <div>
                <label className="block text-sm font-semibold mb-2 text-slate-800 dark:text-slate-200">{t('reportForm.locationLabel')}</label>
                <div className="relative">
                  <input 
                    type="text"
                    className="w-full p-3 border border-slate-300 dark:border-slate-600 rounded-xl bg-slate-50 dark:bg-slate-700 pl-10 text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-blue-500"
                    placeholder={t('reportForm.locationPlaceholder')}
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                  />
                  <i className="fa-solid fa-location-dot absolute left-3 top-4 text-slate-400"></i>
                </div>
                <button 
                  onClick={() => navigator.geolocation.getCurrentPosition((pos) => setAddress(`${pos.coords.latitude}, ${pos.coords.longitude}`))}
                  className="text-xs text-blue-600 dark:text-blue-400 font-bold mt-2 hover:underline"
                >
                  <i className="fa-solid fa-crosshairs mr-1"></i> {t('reportForm.useCurrentLocation')}
                </button>
              </div>
            </div>
          )}

          {step === 3 && (
             <div className="space-y-4 text-center">
              <label className="block text-sm font-semibold mb-2 text-left text-slate-800 dark:text-slate-200">{t('reportForm.evidenceLabel')}</label>
              
              {isCameraOpen ? (
                <div className="relative">
                  <video ref={videoRef} autoPlay playsInline className="w-full rounded-lg bg-slate-900 aspect-video"></video>
                  <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-4">
                    <button onClick={handleCapturePhoto} className="w-16 h-16 bg-white rounded-full flex items-center justify-center border-4 border-slate-300 active:scale-95 transition-transform" aria-label="Capturar Foto">
                      <div className="w-12 h-12 bg-red-500 rounded-full"></div>
                    </button>
                  </div>
                  <button onClick={handleCloseCamera} className="absolute top-2 right-2 text-white bg-black/50 w-8 h-8 rounded-full hover:bg-black/75" aria-label="Fechar Câmera">
                    <i className="fa-solid fa-xmark"></i>
                  </button>
                </div>
              ) : (
                <div className="border-2 border-dashed border-slate-300 dark:border-slate-600 rounded-2xl p-6 transition-colors">
                  {image ? (
                    <div className="relative inline-block">
                      <img src={image} alt="Evidência" className="max-h-48 mx-auto rounded-lg shadow" />
                      <button onClick={() => setImage(null)} className="absolute -top-2 -right-2 bg-red-500 text-white w-6 h-6 rounded-full text-xs shadow-lg hover:bg-red-600" aria-label="Remover Imagem">
                        <i className="fa-solid fa-xmark"></i>
                      </button>
                    </div>
                  ) : (
                    <div className="text-slate-500 dark:text-slate-400 space-y-4">
                      {loading ? (
                         <div className="flex flex-col items-center justify-center">
                           <div className="w-8 h-8 border-2 border-slate-200 dark:border-slate-600 border-t-blue-600 rounded-full animate-spin"></div>
                           <p className="text-sm mt-2">{t('reportForm.optimizing')}</p>
                         </div>
                      ) : (
                        <>
                          <p>{t('reportForm.attachInfo')}</p>
                          <div className="flex justify-center gap-4">
                              <button
                                onClick={() => fileInputRef.current?.click()}
                                className="flex-1 p-3 bg-slate-100 dark:bg-slate-700 rounded-xl hover:bg-slate-200 dark:hover:bg-slate-600 transition-colors font-semibold text-slate-700 dark:text-slate-200"
                              >
                                <i className="fa-solid fa-paperclip mr-2"></i> {t('reportForm.attachFile')}
                              </button>
                              <button
                                onClick={handleOpenCamera}
                                className="flex-1 p-3 bg-slate-100 dark:bg-slate-700 rounded-xl hover:bg-slate-200 dark:hover:bg-slate-600 transition-colors font-semibold text-slate-700 dark:text-slate-200"
                              >
                                <i className="fa-solid fa-camera mr-2"></i> {t('reportForm.takePhoto')}
                              </button>
                          </div>
                        </>
                      )}
                    </div>
                  )}
                </div>
              )}

              <input 
                type="file" 
                ref={fileInputRef} 
                onChange={handleImageChange} 
                className="hidden" 
                accept="image/*"
              />
            </div>
          )}
        </div>

        <div className="p-4 bg-slate-50 dark:bg-slate-800 border-t border-slate-200 dark:border-slate-700 flex gap-3">
          {step > 1 && (
            <button 
              onClick={() => setStep(step - 1)}
              className="flex-1 py-3 px-4 rounded-xl font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700"
            >
              {t('reportForm.buttons.back')}
            </button>
          )}
          <button 
            disabled={loading || (step === 1 && (!category || description.length < 10))}
            onClick={step === 3 ? handleSubmit : handleNext}
            className="flex-[2] py-3 px-4 bg-blue-600 text-white rounded-xl font-bold shadow-lg shadow-blue-200 active:scale-95 transition-all disabled:opacity-50"
          >
            {loading ? (
              <i className="fa-solid fa-spinner fa-spin"></i>
            ) : step === 3 ? t('reportForm.buttons.submit')
             : t('reportForm.buttons.next')
            }
          </button>
        </div>
      </div>
    </div>
  );
};
