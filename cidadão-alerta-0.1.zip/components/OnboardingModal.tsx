import React, { useState } from 'react';
import { useI18n } from '../i18n/index.tsx';

interface OnboardingModalProps {
  onClose: () => void;
  onOpenTerms: () => void;
  onOpenPrivacy: () => void;
}

export const OnboardingModal: React.FC<OnboardingModalProps> = ({ onClose, onOpenTerms, onOpenPrivacy }) => {
  const { t } = useI18n();
  const [agreedTerms, setAgreedTerms] = useState(false);
  const [agreedPrivacy, setAgreedPrivacy] = useState(false);

  const canProceed = agreedTerms && agreedPrivacy;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
      <div className="bg-white dark:bg-slate-800 w-full max-w-sm rounded-3xl shadow-2xl p-8 text-center transform animate-in slide-in-from-bottom-10">
        <div className="w-20 h-20 mx-auto bg-blue-100 dark:bg-blue-900/50 rounded-full flex items-center justify-center border-8 border-blue-50 dark:border-blue-800/30 mb-6">
            <i className="fa-solid fa-shield-heart text-4xl text-blue-600 dark:text-blue-400"></i>
        </div>
        
        <h2 className="text-2xl font-black text-slate-800 dark:text-slate-100 mb-4">{t('onboarding.title')}</h2>
        
        <ul className="space-y-3 text-slate-600 dark:text-slate-300 text-left mb-6">
            <li className="flex items-start">
                <i className="fa-solid fa-phone-volume text-blue-500 dark:text-blue-400 w-6 text-center mr-2 pt-1"></i>
                <span>{t('onboarding.line1')}</span>
            </li>
            <li className="flex items-start">
                <i className="fa-solid fa-user-secret text-blue-500 dark:text-blue-400 w-6 text-center mr-2 pt-1"></i>
                <span>{t('onboarding.line2')}</span>
            </li>
            <li className="flex items-start">
                <i className="fa-solid fa-lock text-blue-500 dark:text-blue-400 w-6 text-center mr-2 pt-1"></i>
                <span>{t('onboarding.line3')}</span>
            </li>
        </ul>
        
        <div className="space-y-3 text-left text-xs text-slate-500 dark:text-slate-400 mb-6">
            <div className="flex items-start">
                <input
                    id="terms"
                    type="checkbox"
                    checked={agreedTerms}
                    onChange={() => setAgreedTerms(!agreedTerms)}
                    className="mt-0.5 mr-2 h-4 w-4 rounded border-gray-300 dark:border-gray-600 text-blue-600 focus:ring-blue-500"
                />
                <label htmlFor="terms">
                    {t('onboarding.agree_prefix')}{' '}
                    <button onClick={onOpenTerms} className="font-bold text-blue-600 dark:text-blue-400 hover:underline">
                        {t('onboarding.terms_link')}
                    </button>.
                </label>
            </div>
            <div className="flex items-start">
                <input
                    id="privacy"
                    type="checkbox"
                    checked={agreedPrivacy}
                    onChange={() => setAgreedPrivacy(!agreedPrivacy)}
                    className="mt-0.5 mr-2 h-4 w-4 rounded border-gray-300 dark:border-gray-600 text-blue-600 focus:ring-blue-500"
                />
                <label htmlFor="privacy">
                    {t('onboarding.agree_prefix')}{' '}
                    <button onClick={onOpenPrivacy} className="font-bold text-blue-600 dark:text-blue-400 hover:underline">
                        {t('onboarding.privacy_link')}
                    </button>.
                </label>
            </div>
        </div>


        <button
            onClick={onClose}
            disabled={!canProceed}
            className="w-full py-4 px-4 bg-blue-600 text-white rounded-xl font-bold text-lg shadow-lg shadow-blue-200 active:scale-95 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
        >
            {t('onboarding.button')}
        </button>
      </div>
    </div>
  );
};
