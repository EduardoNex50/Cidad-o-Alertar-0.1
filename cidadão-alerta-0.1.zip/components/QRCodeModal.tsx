import React from 'react';
import QRCode from 'qrcode.react';
import { useI18n } from '../i18n/index.tsx';

interface QRCodeModalProps {
  onClose: () => void;
  url: string;
}

export const QRCodeModal: React.FC<QRCodeModalProps> = ({ onClose, url }) => {
    const { t } = useI18n();

    return (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
            <div className="bg-white dark:bg-slate-800 w-full max-w-sm rounded-3xl shadow-2xl p-8 text-center transform animate-in slide-in-from-bottom-10" role="dialog" aria-modal="true" aria-labelledby="qr-title">
                <div className="flex justify-between items-center mb-4">
                     <h2 id="qr-title" className="text-xl font-black text-slate-800 dark:text-slate-100">{t('profile.share.qrTitle')}</h2>
                     <button onClick={onClose} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-300" aria-label={t('buttons.close')}>
                       <i className="fa-solid fa-xmark text-xl"></i>
                     </button>
                </div>
                <p className="text-slate-600 dark:text-slate-300 mb-6">{t('profile.share.qrMessage')}</p>
                <div className="p-4 bg-white rounded-2xl inline-block border dark:border-slate-600">
                    <QRCode value={url} size={200} level="H" imageSettings={{excavate: true}}/>
                </div>
                <input
                    type="text"
                    readOnly
                    value={url}
                    className="w-full mt-6 p-2 text-center bg-slate-100 dark:bg-slate-700 border border-slate-200 dark:border-slate-600 rounded-lg text-sm text-slate-600 dark:text-slate-300"
                    aria-label="URL da Aplicação"
                />
                 <button
                    onClick={onClose}
                    className="mt-6 w-full py-3 px-4 rounded-xl font-bold text-sm text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
                >
                    {t('buttons.close')}
                </button>
            </div>
        </div>
    );
};
