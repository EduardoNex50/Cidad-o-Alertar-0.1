import React from 'react';

interface AppLogoProps {
  className?: string;
}

export const AppLogo: React.FC<AppLogoProps> = ({ className }) => {
  return (
    <svg
      className={className}
      viewBox="0 0 100 100"
      xmlns="http://www.w3.org/2000/svg"
      aria-label="Logótipo do Cidadão Alerta"
    >
        <path 
            d="M50 0 L95 15 V55 C95 85 50 100 50 100 C50 100 5 85 5 55 V15 L50 0 Z" 
            fill="#FFFFFF"
        />
        <path
            d="M50 10 L85 22 V55 C85 78 50 90 50 90 C50 90 15 78 15 55 V22 L50 10 Z"
            fill="#3b82f6"
        />
    </svg>
  );
};
