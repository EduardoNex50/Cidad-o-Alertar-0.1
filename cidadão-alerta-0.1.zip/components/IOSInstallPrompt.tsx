import React from 'react';
import { useI18n } from '../i18n/index.tsx';

interface IOSInstallPromptProps {
  onClose: () => void;
}

export const IOSInstallPrompt: React.FC<IOSInstallPromptProps> = ({ onClose }) => {
  const { t } = useI18n();
  return (
    <div className="bg-blue-50 dark:bg-slate-800 rounded-3xl p-6 border border-blue-200 dark:border-slate-700 text-center relative">
        <button 
            onClick={onClose} 
            className="absolute top-3 right-3 text-blue-300 dark:text-slate-500 hover:text-blue-500 dark:hover:text-slate-300 w-6 h-6"
            aria-label="Fechar instrução de instalação"
        >
            <i className="fa-solid fa-xmark"></i>
        </button>
        <div className="w-12 h-12 mx-auto bg-blue-600 text-white rounded-xl flex items-center justify-center mb-4">
            <i className="fa-brands fa-apple text-2xl"></i>
        </div>
        <h4 className="font-bold text-slate-800 dark:text-slate-100 mb-2">{t('pwa.iosInstallTitle')}</h4>
        <p className="text-sm text-slate-600 dark:text-slate-300">
            {t('pwa.iosInstallMessage')}
        </p>
    </div>
  );
};
