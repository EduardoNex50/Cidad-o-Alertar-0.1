
import React, { useState, useEffect, useRef } from 'react';

interface LazyImageProps {
  src: string;
  alt: string;
  className?: string;
}

export const LazyImage: React.FC<LazyImageProps> = ({ src, alt, className }) => {
  const [imageSrc, setImageSrc] = useState<string | null>(null);
  const placeholderRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let observer: IntersectionObserver;

    if (placeholderRef.current) {
      observer = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              setImageSrc(src);
              observer.unobserve(entry.target);
            }
          });
        },
        { rootMargin: '0px 0px 200px 0px' } // Carrega a imagem 200px antes de entrar no viewport
      );
      observer.observe(placeholderRef.current);
    }

    return () => {
      if (observer && placeholderRef.current) {
        // eslint-disable-next-line react-hooks/exhaustive-deps
        observer.unobserve(placeholderRef.current);
      }
    };
  }, [src]);

  // Se a imagem ainda não foi carregada, mostra um placeholder
  if (!imageSrc) {
    return (
      <div
        ref={placeholderRef}
        className={`${className} bg-slate-200 animate-pulse`}
      />
    );
  }

  // Quando carregada, exibe a imagem
  return <img src={imageSrc} alt={alt} className={className} />;
};
