import React from 'react';

interface AppIconProps {
  className?: string;
}

export const AppIcon: React.FC<AppIconProps> = ({ className }) => {
  return (
    <svg 
      className={className}
      viewBox="0 0 100 100" 
      xmlns="http://www.w3.org/2000/svg"
      aria-label="Ícone do Cidadão Alerta"
    >
      <defs>
        <linearGradient id="shieldGradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" style={{ stopColor: '#3b82f6', stopOpacity: 1 }} />
          <stop offset="100%" style={{ stopColor: '#1d4ed8', stopOpacity: 1 }} />
        </linearGradient>
      </defs>
      <path 
        d="M50 0 L95 15 V55 C95 85 50 100 50 100 C50 100 5 85 5 55 V15 L50 0 Z" 
        fill="url(#shieldGradient)" 
      />
      <path 
        d="M50 35 C 40 25, 25 30, 25 45 C 25 60, 50 75, 50 75 C 50 75, 75 60, 75 45 C 75 30, 60 25, 50 35 Z"
        fill="white"
        transform="scale(0.8) translate(12.5, 12.5)"
        stroke="#FFFFFF"
        strokeWidth="3"
      />
    </svg>
  );
};
