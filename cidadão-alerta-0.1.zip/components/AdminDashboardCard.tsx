import React from 'react';
import { useI18n } from '../i18n/index.tsx';

export const AdminDashboardCard: React.FC = () => {
    const { t } = useI18n();

    const handleAccessClick = () => {
        alert(t('profile.dashboard.devMessage'));
    };

    return (
        <div className="bg-slate-800 rounded-3xl p-6 border border-slate-700 text-left text-white">
            <div className="flex items-center mb-4">
                <div className="w-10 h-10 bg-slate-600 rounded-xl flex items-center justify-center text-white mr-4">
                    <i className="fa-solid fa-user-shield"></i>
                </div>
                <div>
                    <h4 className="font-bold text-white">{t('profile.dashboard.title')}</h4>
                    <p className="text-xs text-slate-400">{t('profile.dashboard.description')}</p>
                </div>
            </div>
            <p className="text-sm text-slate-300 mb-4">{t('profile.dashboard.info')}</p>
            <button
                onClick={handleAccessClick}
                className="w-full flex items-center justify-center py-3 px-4 bg-indigo-500 text-white rounded-xl font-bold text-sm hover:bg-indigo-600 transition-colors"
            >
                <i className="fa-solid fa-arrow-right-to-bracket mr-2"></i>
                {t('profile.dashboard.button')}
            </button>
        </div>
    );
};
