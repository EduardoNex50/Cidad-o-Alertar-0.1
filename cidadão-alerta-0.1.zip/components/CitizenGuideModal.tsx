import React, { useState, useEffect } from 'react';
import { useI18n } from '../i18n/index.tsx';
import { getGuideContent } from '../services/geminiService.ts';

interface CitizenGuideModalProps {
  onClose: () => void;
}

type GuideSection = {
  title: string;
  icon: string;
  content: string;
};

export const CitizenGuideModal: React.FC<CitizenGuideModalProps> = ({ onClose }) => {
  const { t, language } = useI18n();
  const [loading, setLoading] = useState(true);
  const [sections, setSections] = useState<GuideSection[]>([]);
  const [error, setError] = useState<string | null>(null);
  
  useEffect(() => {
    const fetchGuide = async () => {
      setLoading(true);
      setError(null);
      try {
        const content = await getGuideContent(language);
        if(content) {
            setSections(content);
        } else {
            setError("Failed to load guide content.");
        }
      } catch (e) {
        setError("An error occurred while fetching the guide.");
        console.error(e);
      } finally {
        setLoading(false);
      }
    };
    
    fetchGuide();
  }, [language]);

  return (
     <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
      <div className="bg-white dark:bg-slate-800 w-full max-w-lg rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        <div className="p-4 border-b border-slate-200 dark:border-slate-700 flex justify-between items-center bg-slate-50 dark:bg-slate-800">
          <h2 className="font-bold text-lg text-slate-800 dark:text-slate-100">{t('citizenGuide.title')}</h2>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-300">
            <i className="fa-solid fa-xmark text-xl"></i>
          </button>
        </div>
        <div className="p-6 overflow-y-auto">
          {loading ? (
            <div className="text-center py-10">
              <div className="w-8 h-8 border-2 border-slate-200 dark:border-slate-700 border-t-blue-600 rounded-full animate-spin mx-auto"></div>
              <p className="text-sm text-slate-500 dark:text-slate-400 mt-4">{t('citizenGuide.loading')}</p>
            </div>
          ) : error ? (
            <div className="text-center py-10 text-red-600 dark:text-red-400">
                <i className="fa-solid fa-exclamation-triangle text-3xl mb-3"></i>
                <p>{error}</p>
            </div>
          ) : (
            <div className="space-y-6">
                <p className="text-slate-600 dark:text-slate-300 text-sm">{t('citizenGuide.intro')}</p>
                {sections.map((section, index) => (
                    <details key={index} className="bg-slate-50 dark:bg-slate-700/50 border border-slate-200 dark:border-slate-700 rounded-xl" open={index === 0}>
                        <summary className="p-4 font-bold text-slate-700 dark:text-slate-200 cursor-pointer flex items-center justify-between list-none">
                            <div className="flex items-center">
                                <i className={`fa-solid ${section.icon} w-6 text-center text-blue-600 dark:text-blue-400 mr-3`}></i>
                                <span>{section.title}</span>
                            </div>
                            <i className="fa-solid fa-chevron-down transition-transform duration-200"></i>
                        </summary>
                        <div className="p-4 border-t border-slate-200 dark:border-slate-700 text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                            <p>{section.content}</p>
                        </div>
                    </details>
                ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
