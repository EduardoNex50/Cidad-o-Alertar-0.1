import React from 'react';
import { Report } from '../types.ts';
import { useI18n } from '../i18n/index.tsx';
import { LazyImage } from './LazyImage.tsx';

interface ReportDetailModalProps {
  report: Report;
  onClose: () => void;
}

export const ReportDetailModal: React.FC<ReportDetailModalProps> = ({ report, onClose }) => {
  const { t } = useI18n();

  const getStatusInfo = (status: Report['status']) => {
      switch (status) {
          case 'Pendente Sincronização':
              return { text: t('history.status.syncing'), color: 'bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-200' };
          case 'Pendente':
              return { text: t('history.status.pending'), color: 'bg-amber-100 dark:bg-amber-900/50 text-amber-700 dark:text-amber-200' };
          case 'Resolvido':
              return { text: t('history.status.resolved'), color: 'bg-emerald-100 dark:bg-emerald-900/50 text-emerald-700 dark:text-emerald-200' };
          default:
               return { text: status, color: 'bg-blue-100 dark:bg-blue-900/50 text-blue-700 dark:text-blue-200' };
      }
  };
  
  const statusInfo = getStatusInfo(report.status);
  const mapUrl = report.location.lat && report.location.lng 
    ? `https://www.openstreetmap.org/?mlat=${report.location.lat}&mlon=${report.location.lng}#map=16/${report.location.lat}/${report.location.lng}`
    : `https://www.openstreetmap.org/search?query=${encodeURIComponent(report.location.address)}`;

  return (
     <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
      <div className="bg-white dark:bg-slate-800 w-full max-w-lg rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        <div className="p-4 border-b border-slate-200 dark:border-slate-700 flex justify-between items-center bg-slate-50 dark:bg-slate-800">
          <h2 className="font-bold text-lg text-slate-800 dark:text-slate-100">{t('reportDetail.title')}</h2>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-300">
            <i className="fa-solid fa-xmark text-xl"></i>
          </button>
        </div>
        <div className="p-6 overflow-y-auto space-y-4">
            {report.evidence && (
                <div>
                    <h3 className="text-sm font-bold uppercase text-slate-500 dark:text-slate-400 mb-2">{t('reportDetail.evidence')}</h3>
                    <LazyImage src={report.evidence} alt={`Evidência para ${report.type}`} className="w-full h-auto max-h-64 object-cover rounded-lg bg-slate-200 dark:bg-slate-700" />
                </div>
            )}
            
            <div className="grid grid-cols-2 gap-4">
                <div>
                    <h3 className="text-xs font-bold uppercase text-slate-500 dark:text-slate-400">{t('reportDetail.status')}</h3>
                    <p className={`inline-block px-2 py-0.5 mt-1 rounded text-xs font-bold ${statusInfo.color}`}>{statusInfo.text}</p>
                </div>
                <div>
                    <h3 className="text-xs font-bold uppercase text-slate-500 dark:text-slate-400">{t('reportDetail.date')}</h3>
                    <p className="text-sm text-slate-800 dark:text-slate-200 font-medium mt-1">{new Date(report.timestamp).toLocaleString()}</p>
                </div>
                <div>
                    <h3 className="text-xs font-bold uppercase text-slate-500 dark:text-slate-400">{t('reportDetail.agency')}</h3>
                    <p className="text-sm text-slate-800 dark:text-slate-200 font-medium mt-1">{report.agency}</p>
                </div>
                 <div>
                    <h3 className="text-xs font-bold uppercase text-slate-500 dark:text-slate-400">{t('reportDetail.category')}</h3>
                    <p className="text-sm text-slate-800 dark:text-slate-200 font-medium mt-1">{report.type}</p>
                </div>
            </div>

            <div>
                <h3 className="text-xs font-bold uppercase text-slate-500 dark:text-slate-400">{t('reportDetail.location')}</h3>
                <p className="text-sm text-slate-800 dark:text-slate-200 font-medium mt-1">{report.location.address}</p>
                {mapUrl && (
                    <a href={mapUrl} target="_blank" rel="noopener noreferrer" className="text-xs text-blue-600 dark:text-blue-400 font-bold mt-1 hover:underline inline-block">
                        <i className="fa-solid fa-map-location-dot mr-1"></i> {t('reportDetail.viewOnMap')}
                    </a>
                )}
            </div>

            <div>
                <h3 className="text-xs font-bold uppercase text-slate-500 dark:text-slate-400">{t('reportDetail.description')}</h3>
                <p className="text-sm text-slate-800 dark:text-slate-200 mt-2 bg-slate-50 dark:bg-slate-700 p-3 rounded-lg whitespace-pre-wrap">{report.description}</p>
            </div>

        </div>
         <div className="p-4 bg-slate-50 dark:bg-slate-800 border-t border-slate-200 dark:border-slate-700 shrink-0">
            <button
                onClick={onClose}
                className="w-full py-3 px-4 rounded-xl font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 bg-slate-100 dark:bg-slate-600/50 transition-colors"
            >
                {t('buttons.close')}
            </button>
        </div>
      </div>
    </div>
  );
};
