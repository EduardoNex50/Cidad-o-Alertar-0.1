import React, { useState } from 'react';
import { useI18n } from '../i18n/index.tsx';
import { Report } from '../types.ts';
import { generateReportPDF } from '../utils/pdfGenerator.ts';

interface SuccessModalProps {
  title: string;
  message: string;
  onClose: () => void;
  onShare?: () => void;
  report?: Report;
}

export const SuccessModal: React.FC<SuccessModalProps> = ({ title, message, onClose, onShare, report }) => {
  const { t } = useI18n();
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  
  React.useEffect(() => {
    // Apenas fecha automaticamente se não houver um relatório para baixar.
    if (!report) {
      const timer = setTimeout(() => {
        onClose();
      }, 4000);

      return () => clearTimeout(timer);
    }
  }, [onClose, report]);

  const handleDownloadPdf = async () => {
    if (!report) return;
    setIsGeneratingPdf(true);
    try {
      await generateReportPDF(report, t);
    } catch (error) {
      console.error("Falha ao gerar PDF", error);
      alert(t('errors.pdfGenerationFailed', { fallback: "Não foi possível gerar o PDF." }));
    } finally {
      setIsGeneratingPdf(false);
    }
  };


  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in" role="alertdialog" aria-modal="true" aria-labelledby="success-title">
      <div className="bg-white dark:bg-slate-800 w-full max-w-sm rounded-3xl shadow-2xl p-8 text-center transform animate-in slide-in-from-bottom-10">
        <div className="w-20 h-20 mx-auto bg-emerald-100 dark:bg-emerald-900/50 rounded-full flex items-center justify-center border-8 border-emerald-50 dark:border-emerald-800/50 mb-6 animate-in zoom-in-50">
            <i className="fa-solid fa-check text-5xl text-emerald-500 dark:text-emerald-400"></i>
        </div>
        
        <h2 id="success-title" className="text-2xl font-black text-slate-800 dark:text-slate-100 mb-2">{title}</h2>
        <p className="text-slate-600 dark:text-slate-300 mb-8">
          {message}
        </p>

        <div className="space-y-3">
          {report && (
            <button
              onClick={handleDownloadPdf}
              disabled={isGeneratingPdf}
              className="w-full py-4 px-4 bg-blue-600 text-white rounded-xl font-bold text-lg shadow-lg shadow-blue-200 active:scale-95 transition-all disabled:bg-blue-400"
            >
              <i className={`fa-solid ${isGeneratingPdf ? 'fa-spinner fa-spin' : 'fa-file-arrow-down'} mr-2`}></i>
              {isGeneratingPdf ? t('successModal.generatingProof') : t('successModal.downloadProof')}
            </button>
          )}

          {onShare && (
             <button 
               onClick={onShare}
               className="w-full py-3 px-4 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 text-slate-700 dark:text-slate-200 rounded-xl font-bold text-sm hover:bg-slate-50 dark:hover:bg-slate-600 active:scale-95 transition-all"
             >
               <i className="fa-solid fa-share-nodes mr-2"></i>
               {t('successModal.share')}
             </button>
          )}
          
          <button
              onClick={onClose}
              className="w-full py-2 px-4 rounded-xl font-bold text-sm text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
          >
              {t('buttons.close')}
          </button>
        </div>
      </div>
    </div>
  );
};
