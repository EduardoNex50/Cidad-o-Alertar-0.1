
import React from 'react';

interface EmergencyButtonProps {
  label: string;
  number: string;
  icon: string;
  color: string;
}

const EmergencyButtonComponent: React.FC<EmergencyButtonProps> = ({ label, number, icon, color }) => {
  return (
    <a
      href={`tel:${number}`}
      className={`${color} flex flex-col items-center justify-center p-4 rounded-2xl text-white shadow-lg active:scale-95 transition-all hover:brightness-110`}
    >
      <i className={`fa-solid ${icon} text-3xl mb-2`}></i>
      <span className="text-xs font-bold uppercase tracking-wider">{label}</span>
      <span className="text-xl font-black">{number}</span>
    </a>
  );
};

export const EmergencyButton = React.memo(EmergencyButtonComponent);
