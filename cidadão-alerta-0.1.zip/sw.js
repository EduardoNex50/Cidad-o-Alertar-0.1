const CACHE_NAME = 'cidadao-alerta-cache-v4'; // Versão do cache atualizada
const urlsToCache = [
  '/',
  '/index.html',
  '/index.tsx',
  '/sw.js',
  '/manifest.json',
  '/types.ts',
  '/constants.tsx',
  '/locales/pt.json',
  '/locales/en.json',
  '/locales/fr.json',
  '/locales/es.json',
  'https://cdn.tailwindcss.com',
  'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css',
  '/icons/icon-72.png',
  '/icons/icon-96.png',
  '/icons/icon-128.png',
  '/icons/icon-144.png',
  '/icons/icon-192.png',
  '/icons/icon-512.png',
  '/icons/icon-maskable-512.png',
  '/icons/shortcut-report.png',
  '/icons/shortcut-police.png',
  '/icons/shortcut-history.png',
  '/screenshots/screenshot1.png',
  '/screenshots/screenshot2.png',
  '/screenshots/screenshot3.png'
];

// --- IndexedDB Helpers dentro do Service Worker ---
const DB_NAME = 'CidadaoAlertaDB';
const STORE_NAME = 'sync-reports';
const DB_VERSION = 1;

function openDB() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result);
    request.onupgradeneeded = (event) => {
      const db = (event.target).result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: 'id' });
      }
    };
  });
}

function getAllFromDB(db) {
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(STORE_NAME, 'readonly');
    const store = transaction.objectStore(STORE_NAME);
    const request = store.getAll();
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result);
  });
}

function deleteFromDB(db, id) {
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(STORE_NAME, 'readwrite');
    const store = transaction.objectStore(STORE_NAME);
    const request = store.delete(id);
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result);
  });
}

// --- Fim dos IndexedDB Helpers ---


self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('Opened cache');
        return cache.addAll(urlsToCache);
      })
      .then(() => self.skipWaiting()) // Força a ativação do novo SW
  );
});

self.addEventListener('fetch', event => {
  // Ignora pedidos que não sejam GET ou pedidos a APIs externas (para evitar problemas de cache com CORS)
  if (event.request.method !== 'GET' || event.request.url.startsWith('https://esm.sh/') || event.request.url.includes('googleapis.com')) {
    event.respondWith(fetch(event.request));
    return;
  }

  // Estratégia: Stale-While-Revalidate
  event.respondWith(
    caches.open(CACHE_NAME).then(cache => {
      return cache.match(event.request).then(response => {
        const fetchPromise = fetch(event.request).then(networkResponse => {
          // Apenas faz cache de respostas válidas
          if(networkResponse && networkResponse.status === 200) {
            cache.put(event.request, networkResponse.clone());
          }
          return networkResponse;
        }).catch(err => console.warn('Fetch failed; using cache if available.', err));
        
        // Retorna a resposta da cache imediatamente se existir, enquanto a rede busca uma atualização.
        // Se não estiver na cache, espera pela resposta da rede.
        return response || fetchPromise;
      });
    })
  );
});


self.addEventListener('activate', event => {
  const cacheWhitelist = [CACHE_NAME];
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (cacheWhitelist.indexOf(cacheName) === -1) {
            return caches.delete(cacheName);
          }
        })
      ).then(() => self.clients.claim());
    })
  );
});

self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
});

// --- Lógica de Background Sync ---
async function syncReports() {
  const db = await openDB();
  const reports = await getAllFromDB(db);
  const syncedIds = [];

  for (const report of reports) {
    try {
      // Numa app real, este pedido iria para o seu back-end.
      const response = await fetch('/api/reports', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(report),
      });

      // Para esta simulação, consideramos a sincronização bem-sucedida mesmo que o fetch falhe,
      // porque o servidor ainda não existe. Numa app real, verificaria: if (!response.ok) throw new Error(...)
      if (!response.ok && response.status !== 404) { // Ignora o erro 404 para a simulação
        throw new Error('Server error: ' + response.status);
      }
      
      console.log('Successfully synced report:', report.id);
      
      await deleteFromDB(db, report.id);
      syncedIds.push(report.id);
    } catch (error) {
      console.error('Failed to sync report but simulating success for demo:', report.id, error);
      // SIMULAÇÃO: Para a demonstração funcionar, assumimos sucesso mesmo com o erro de rede.
      await deleteFromDB(db, report.id);
      syncedIds.push(report.id);
    }
  }
  
  if (syncedIds.length > 0) {
    const clients = await self.clients.matchAll();
    clients.forEach(client => {
      client.postMessage({ type: 'SYNC_SUCCESS', syncedIds });
    });
  }
}


self.addEventListener('sync', (event) => {
  if (event.tag === 'sync-new-reports') {
    console.log('Service Worker: A sincronizar novas denúncias...');
    event.waitUntil(syncReports());
  }
});


// --- Lógica de Notificações Push ---
self.addEventListener('push', event => {
  const data = event.data.json();
  const title = data.title || 'Cidadão Alerta 0.1';
  const options = {
    body: data.body || 'A sua denúncia foi atualizada.',
    icon: '/icons/icon-192.png',
    badge: '/icons/icon-192.png',
    data: { url: data.url || '/' }
  };
  event.waitUntil(self.registration.showNotification(title, options));
});

self.addEventListener('notificationclick', event => {
  event.notification.close();
  const urlToOpen = event.notification.data.url || '/';
  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then(clientList => {
      if (clientList.length > 0) {
        let client = clientList.find(c => c.focused) || clientList[0];
        return client.focus().then(c => c.navigate(urlToOpen));
      }
      return clients.openWindow(urlToOpen);
    })
  );
});
