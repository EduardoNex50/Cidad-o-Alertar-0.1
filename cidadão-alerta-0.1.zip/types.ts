
export enum AgencyType {
  POLICE = 'Polícia Nacional',
  FIRE = 'Bombeiros',
  MEDICAL = 'Emergência Médica (INEMA)',
  IGAI = 'IGAI (Inspecção do Estado)',
  CIVIL_PROTECTION = 'Proteção Civil'
}

export interface Report {
  id: string;
  agency: AgencyType;
  type: string;
  description: string;
  location: {
    lat?: number;
    lng?: number;
    address: string;
  };
  timestamp: Date;
  status: 'Pendente' | 'Recebida' | 'Em Análise' | 'Resolvido' | 'Pendente Sincronização';
  evidence?: string; // Base64 image
}

export interface AgencyInfo {
  id: AgencyType;
  icon: string;
  color: string;
  hotline: string;
  description: string;
}