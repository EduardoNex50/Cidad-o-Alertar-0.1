import { AgencyType, AgencyInfo } from './types.ts';

export const AGENCIES: AgencyInfo[] = [
  {
    id: AgencyType.POLICE,
    icon: 'fa-shield-halved',
    color: 'bg-blue-600',
    hotline: '113',
    description: 'Segurança pública, combate ao crime e ordem social.'
  },
  {
    id: AgencyType.FIRE,
    icon: 'fa-fire-extinguisher',
    color: 'bg-red-600',
    hotline: '115',
    description: 'Combate a incêndios, resgates e salvamentos.'
  },
  {
    id: AgencyType.MEDICAL,
    icon: 'fa-truck-medical',
    color: 'bg-emerald-600',
    hotline: '112',
    description: 'Atendimento pré-hospitalar e transporte de emergência.'
  },
  {
    id: AgencyType.IGAI,
    icon: 'fa-building-shield',
    color: 'bg-amber-600',
    hotline: '900',
    description: 'Fiscalização da administração pública e conduta de agentes.'
  },
  {
    id: AgencyType.CIVIL_PROTECTION,
    icon: 'fa-person-shelter',
    color: 'bg-orange-600',
    hotline: '116',
    description: 'Gestão de desastres naturais e riscos comunitários.'
  }
];

export const REPORT_CATEGORIES = {
  [AgencyType.POLICE]: ['theft', 'domesticViolence', 'disturbance', 'vandalism', 'other'],
  [AgencyType.FIRE]: ['structuralFire', 'forestFire', 'animalRescue', 'flood', 'other'],
  [AgencyType.MEDICAL]: ['roadAccident', 'cardiacArrest', 'respiratoryDistress', 'seriousInjury', 'other'],
  [AgencyType.IGAI]: ['corruption', 'abuseOfAuthority', 'publicMismanagement', 'extortion', 'other'],
  [AgencyType.CIVIL_PROTECTION]: ['collapseRisk', 'fallenTree', 'calamity', 'other']
};