import { Report } from '../types.ts';
import { obfuscateData, deobfuscateData } from '../utils/security.ts';

// --- Funções Auxiliares para simular um armazenamento de dados remoto (usando localStorage) ---

const getReportsFromStorage = (): Report[] => {
    const saved = localStorage.getItem('cidadao_alerta_reports');
    if (saved) {
        try {
            const deobfuscated = deobfuscateData(saved);
            if (deobfuscated) {
                return JSON.parse(deobfuscated).map((report: any) => ({
                    ...report,
                    timestamp: new Date(report.timestamp),
                }));
            }
        } catch (error) {
            console.error("Falha ao carregar ou analisar denúncias do armazenamento.", error);
            localStorage.removeItem('cidadao_alerta_reports');
        }
    }
    return [];
};

const saveReportsToStorage = (reports: Report[]): void => {
    try {
        const sortedReports = reports.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
        const stringified = JSON.stringify(sortedReports);
        const obfuscated = obfuscateData(stringified);
        localStorage.setItem('cidadao_alerta_reports', obfuscated);
    } catch (error) {
        console.error("Falha ao guardar denúncias cifradas.", error);
    }
};

// --- Serviço de API Mockado ---

/**
 * Simula a busca de todas as denúncias do back-end.
 * @returns Uma promessa que resolve com um array de denúncias.
 */
export const fetchReports = async (): Promise<Report[]> => {
    console.log("API_SERVICE: A buscar denúncias...");
    // Simula a latência da rede
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const reports = getReportsFromStorage();
    console.log(`API_SERVICE: Encontradas ${reports.length} denúncias.`);
    return reports;
};

/**
 * Simula a submissão de uma nova denúncia para o back-end.
 * @param report O objeto da denúncia a submeter.
 * @returns Uma promessa que resolve com a denúncia atualizada do servidor.
 */
export const submitReport = async (report: Omit<Report, 'status'>): Promise<Report> => {
    console.log("API_SERVICE: A submeter denúncia...", report);
    // Simula a latência da rede
    await new Promise(resolve => setTimeout(resolve, 1500));

    // Numa app real, o servidor atribuiria o estado. Nós simulamos isso aqui.
    const reportFromServer: Report = {
        ...report,
        status: 'Recebida', // O servidor recebeu a denúncia.
    };

    const allReports = getReportsFromStorage();
    const updatedReports = [reportFromServer, ...allReports];
    saveReportsToStorage(updatedReports);

    console.log("API_SERVICE: Denúncia submetida com sucesso.", reportFromServer);
    return reportFromServer;
};

/**
 * Atualiza os estados das denúncias sincronizadas.
 * @param syncedIds Array de IDs das denúncias que foram sincronizadas com sucesso.
 */
export const updateSyncedReportsStatus = (syncedIds: string[]): Report[] => {
    console.log("API_SERVICE: A atualizar estado das denúncias sincronizadas...", syncedIds);
    const allReports = getReportsFromStorage();
    // FIX: Add an explicit return type to the map callback to ensure the resulting array is of type Report[].
    const updatedReports = allReports.map((report): Report => {
        if (syncedIds.includes(report.id)) {
            return { ...report, status: 'Recebida' };
        }
        return report;
    });
    saveReportsToStorage(updatedReports);
    return updatedReports;
};
