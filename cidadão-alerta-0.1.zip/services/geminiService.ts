import { GoogleGenAI, Type } from "@google/genai";

async function getLocaleData(lang: string) {
  try {
    const response = await fetch(`./locales/${lang}.json`);
    if (response.ok) {
      return await response.json();
    }
  } catch (e) {
    console.error(`Failed to load prompts for ${lang}`, e);
  }
  return null;
}

export const classifyIncident = async (description: string, lang: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  try {
    const localeData = await getLocaleData(lang);
    if (!localeData) throw new Error("Prompts could not be loaded.");

    const prompt = localeData.prompts.classifyIncident.replace('{{description}}', description);

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        systemInstruction: "You are an AI assistant for the 'Cidadão Alerta' app. Your role is to act as an expert emergency services dispatcher. Analyze incident reports with high speed and accuracy, classifying them and providing immediate, helpful advice. You must respond ONLY with a valid JSON object that strictly adheres to the requested schema. Do not add any extra text or explanations.",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            entidade: { type: Type.STRING },
            urgencia: { type: Type.STRING },
            conselho_imediato: { type: Type.STRING }
          },
          required: ["entidade", "urgencia", "conselho_imediato"]
        }
      }
    });
    
    if (response.text) {
        try {
          return JSON.parse(response.text);
        } catch (e) {
          console.error("Failed to parse JSON from Gemini response:", e);
          return null;
        }
    }
    return null;
  } catch (error) {
    console.error("Classification Error:", error);
    return null;
  }
};

export const getGeminiAssistance = async (prompt: string, lang: string): Promise<{ text: string; links: { title: string, uri: string }[] }> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  try {
    const localeData = await getLocaleData(lang);
    if (!localeData) throw new Error("Prompts could not be loaded.");

    const assistancePrompt = localeData.prompts.getAssistance.replace('{{prompt}}', prompt);

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: assistancePrompt,
      config: {
        tools: [{ googleSearch: {} }, { googleMaps: {} }],
      },
    });

    const text = response.text;
    const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
    
    const links: { title: string, uri: string }[] = [];
    for (const chunk of groundingChunks) {
      if (chunk.web && chunk.web.uri) {
        links.push({ title: chunk.web.title || chunk.web.uri, uri: chunk.web.uri });
      } else if (chunk.maps && chunk.maps.uri) {
        links.push({ title: chunk.maps.title || chunk.maps.uri, uri: chunk.maps.uri });
      }
    }
    
    return { text: text || 'Não foi possível obter uma resposta. Tente novamente.', links };
  } catch (error) {
    console.error("Gemini Assistance Error:", error);
    throw new Error('Ocorreu um erro ao comunicar com o assistente.');
  }
};

export const getGuideContent = async (lang: string): Promise<{title: string, icon: string, content: string}[] | null> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  try {
    const localeData = await getLocaleData(lang);
    if (!localeData) throw new Error("Prompts could not be loaded.");
    
    const prompt = localeData.prompts.getGuideContent;

    const result = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            sections: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING },
                  icon: { type: Type.STRING },
                  content: { type: Type.STRING }
                },
                required: ["title", "icon", "content"]
              }
            }
          }
        }
      }
    });

    if (result.text) {
      try {
        return JSON.parse(result.text).sections;
      } catch (e) {
        console.error("Failed to parse JSON from Gemini response for guide:", e);
        return null;
      }
    }
    return null;
  } catch (error) {
    console.error("Guide Content Error:", error);
    return null;
  }
};
