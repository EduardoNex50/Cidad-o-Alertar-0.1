import React, { useState, useEffect, useRef, Suspense, lazy } from 'react';
import { AgencyType, Report, AgencyInfo } from './types.ts';
import { AGENCIES } from './constants.tsx';
import { EmergencyButton } from './components/EmergencyButton.tsx';
import { AgencyCard } from './components/AgencyCard.tsx';
import { ReportItem } from './components/ReportItem.tsx';
import { InstallPWA } from './components/InstallPWA.tsx';
import { IOSInstallPrompt } from './components/IOSInstallPrompt.tsx';
import { UpdatePrompt } from './components/UpdatePrompt.tsx';
import { Spinner } from './components/Spinner.tsx';
import { AppLogo } from './components/AppLogo.tsx';
import { AppIcon } from './components/AppIcon.tsx';
import { addReportToSyncQueue, initDB } from './utils/db.ts';
import { useI18n, LANGUAGES, Language } from './i18n/index.tsx';
import { fetchReports, submitReport, updateSyncedReportsStatus } from './services/apiService.ts';
import { ThemeToggle } from './components/ThemeToggle.tsx';

const ReportForm = lazy(() => import('./components/ReportForm.tsx').then(module => ({ default: module.ReportForm })));
const AIChatBot = lazy(() => import('./components/AIChatBot.tsx').then(module => ({ default: module.AIChatBot })));
const SuccessModal = lazy(() => import('./components/SuccessModal.tsx').then(module => ({ default: module.SuccessModal })));
const OnboardingModal = lazy(() => import('./components/OnboardingModal.tsx').then(module => ({ default: module.OnboardingModal })));
const CitizenGuideModal = lazy(() => import('./components/CitizenGuideModal.tsx').then(module => ({ default: module.CitizenGuideModal })));
const QRCodeModal = lazy(() => import('./components/QRCodeModal.tsx').then(module => ({ default: module.QRCodeModal })));
const AdminDashboardCard = lazy(() => import('./components/AdminDashboardCard.tsx').then(module => ({ default: module.AdminDashboardCard })));
const LegalModal = lazy(() => import('./components/LegalModal.tsx').then(module => ({ default: module.LegalModal })));
const ReportDetailModal = lazy(() => import('./components/ReportDetailModal.tsx').then(module => ({ default: module.ReportDetailModal })));


const VAPID_PUBLIC_KEY = 'BCIVm8q832_E5nqdYL00i5pTEN0a3u8a2w8AdHlDV9TFS9fWnYk_YjwkaxFJlFqG4ORhR2qHjF31Ilo3yNDaAAM';

const App: React.FC = () => {
  const { t, language, setLanguage } = useI18n();
  const [activeTab, setActiveTab] = useState<'home' | 'history' | 'profile'>('home');
  const [selectedAgency, setSelectedAgency] = useState<AgencyInfo | null>(null);
  const [reports, setReports] = useState<Report[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [successInfo, setSuccessInfo] = useState<{title: string, message: string, onShare?: () => void, report?: Report} | null>(null);
  const [notificationPermissionStatus, setNotificationPermissionStatus] = useState<NotificationPermission>('default');
  const [ibanCopied, setIbanCopied] = useState(false);
  const [multicaixaCopied, setMulticaixaCopied] = useState(false);
  const [shareStatus, setShareStatus] = useState<'idle' | 'copied'>('idle');
  const [installPromptEvent, setInstallPromptEvent] = useState<any>(null);
  const [showInstallPrompt, setShowInstallPrompt] = useState(false);
  const [showIOSInstallPrompt, setShowIOSInstallPrompt] = useState(false);
  const [showUpdatePrompt, setShowUpdatePrompt] = useState(false);
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [isGuideOpen, setIsGuideOpen] = useState(false);
  const [isQrModalOpen, setIsQrModalOpen] = useState(false);
  const [isTermsOpen, setIsTermsOpen] = useState(false);
  const [isPrivacyOpen, setIsPrivacyOpen] = useState(false);
  const [viewingReport, setViewingReport] = useState<Report | null>(null);
  const waitingWorkerRef = useRef<ServiceWorker | null>(null);
  const importFileRef = useRef<HTMLInputElement>(null);

  const navItems = [
    { id: 'home', icon: 'fa-house-chimney', label: t('nav.home') },
    { id: 'history', icon: 'fa-clock-rotate-left', label: t('nav.history') },
    { id: 'profile', icon: 'fa-user', label: t('nav.profile') },
  ];

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return t('greetings.morning');
    if (hour < 18) return t('greetings.afternoon');
    return t('greetings.evening');
  };

  useEffect(() => {
    const hasOnboarded = localStorage.getItem('cidadao_alerta_onboarded');
    if (!hasOnboarded) setShowOnboarding(true);

    initDB();
    if ('Notification' in window) setNotificationPermissionStatus(Notification.permission);
    
    const loadInitialData = async () => {
        setIsLoading(true);
        try {
            const initialReports = await fetchReports();
            setReports(initialReports);
        } catch (error) {
            console.error("Falha ao buscar denúncias iniciais:", error);
        } finally {
            setIsLoading(false);
        }
    };
    
    loadInitialData();
  }, []);

  useEffect(() => {
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      if (!/iPad|iPhone|iPod/.test(navigator.userAgent)) {
        setInstallPromptEvent(e);
        setShowInstallPrompt(true);
      }
    };
    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    const handleAppInstalled = () => {
      setInstallPromptEvent(null);
      setShowInstallPrompt(false);
    };
    window.addEventListener('appinstalled', handleAppInstalled);
    const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !(window as any).MSStream;
    const isStandalone = window.matchMedia('(display-mode: standalone)').matches;
    const hasDismissedIOSPrompt = localStorage.getItem('dismissedIOSInstallPrompt');
    if (isIOS && !isStandalone && !hasDismissedIOSPrompt) {
      setShowIOSInstallPrompt(true);
    }
    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('appinstalled', handleAppInstalled);
    };
  }, []);

  useEffect(() => {
    if ('serviceWorker' in navigator) {
      const onNewServiceWorker = (registration: ServiceWorkerRegistration) => {
        if (registration.waiting) {
            waitingWorkerRef.current = registration.waiting;
            setShowUpdatePrompt(true);
        }
      };
      navigator.serviceWorker.ready.then(registration => {
        if (registration.waiting) {
            onNewServiceWorker(registration);
            return;
        }
        registration.onupdatefound = () => {
            const installingWorker = registration.installing;
            if (installingWorker) {
                installingWorker.onstatechange = () => {
                    if (installingWorker.state === 'installed') {
                        onNewServiceWorker(registration);
                    }
                };
            }
        };
      });
      let refreshing = false;
      navigator.serviceWorker.oncontrollerchange = () => {
        if (!refreshing) {
          window.location.reload();
          refreshing = true;
        }
      };
      
      const handleSyncSuccess = (event: MessageEvent) => {
        if (event.data && event.data.type === 'SYNC_SUCCESS') {
          console.log('Sincronização concluída, a atualizar UI...', event.data.syncedIds);
          const updatedReports = updateSyncedReportsStatus(event.data.syncedIds);
          setReports(updatedReports);
        }
      };
      navigator.serviceWorker.addEventListener('message', handleSyncSuccess);

      return () => {
        navigator.serviceWorker.removeEventListener('message', handleSyncSuccess);
      };
    }
  }, []);

  const handleUpdateApp = () => {
    if (waitingWorkerRef.current) {
        waitingWorkerRef.current.postMessage({ type: 'SKIP_WAITING' });
        setShowUpdatePrompt(false);
    }
  };

  const handleReportSubmit = async (data: Partial<Report>) => {
    const newReportData = {
      id: Math.random().toString(36).substr(2, 9),
      agency: data.agency!,
      type: data.type!,
      description: data.description!,
      location: data.location || { address: 'Local desconhecido' },
      timestamp: new Date(),
      evidence: data.evidence,
    };

    setSelectedAgency(null);

    if (navigator.onLine) {
        try {
            setReports(prev => [ { ...newReportData, status: 'Recebida' }, ...prev]);
            const savedReport = await submitReport(newReportData);
            setReports(prev => prev.map(r => r.id === savedReport.id ? savedReport : r));
            setSuccessInfo({ title: t('successModal.reportSubmitted.title'), message: t('successModal.reportSubmitted.message'), report: savedReport });
        } catch (error) {
            console.error("Falha ao submeter denúncia:", error);
            const offlineReport: Report = { ...newReportData, status: 'Pendente Sincronização' };
            setReports(prev => prev.map(r => r.id === offlineReport.id ? offlineReport : r));
            await addReportToSyncQueue(offlineReport);
        }
    } else {
        const offlineReport: Report = { ...newReportData, status: 'Pendente Sincronização' };
        setReports(prev => [offlineReport, ...prev]);
        await addReportToSyncQueue(offlineReport);
        if ('serviceWorker' in navigator && 'SyncManager' in window) {
            const registration = await navigator.serviceWorker.ready;
            await (registration as any).sync.register('sync-new-reports');
        }
        setSuccessInfo({ title: t('successModal.reportSaved.title'), message: t('successModal.reportSaved.message'), report: offlineReport });
    }
  };
  
  const handleExportData = async () => {
    const allReports = await fetchReports();
    const dataStr = JSON.stringify(allReports, null, 2);
    const dataBlob = new Blob([dataStr], { type: "application/json" });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `backup_cidadao_alerta_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    
    setSuccessInfo({ title: t('successModal.exportSuccess.title'), message: t('successModal.exportSuccess.message') });
  };
  
  const handleImportData = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
        try {
            const text = e.target?.result as string;
            const importedReports = JSON.parse(text);

            if (Array.isArray(importedReports) && (importedReports.length === 0 || importedReports[0].id)) {
                 const reportsWithDates = importedReports.map((report: Report) => ({
                    ...report,
                    timestamp: new Date(report.timestamp),
                 }));
                 setReports(prevReports => {
                    const combined = [...prevReports, ...reportsWithDates];
                    const uniqueReports = Array.from(new Map(combined.map(r => [r.id, r])).values())
                        .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
                    uniqueReports.forEach(report => submitReport(report));
                    return uniqueReports;
                 });
                 setSuccessInfo({ title: t('successModal.importSuccess.title'), message: t('successModal.importSuccess.message') });
            } else {
                throw new Error("Formato de ficheiro inválido.");
            }
        } catch (error) {
            alert(t('errors.importFailed'));
            console.error("Erro na importação:", error);
        } finally {
            if(importFileRef.current) importFileRef.current.value = "";
        }
    };
    reader.readAsText(file);
  };


  const handleNotificationPermission = async () => {
    if (!('Notification' in window) || !('serviceWorker' in navigator)) {
      alert('Este navegador não suporta notificações.');
      return;
    }
    const permission = await Notification.requestPermission();
    setNotificationPermissionStatus(permission);
    if (permission === 'granted') {
      try {
        const swRegistration = await navigator.serviceWorker.ready;
        await swRegistration.pushManager.subscribe({
          userVisibleOnly: true,
          applicationServerKey: VAPID_PUBLIC_KEY,
        });
      } catch (error) {
        console.error('Falha ao subscrever notificações push:', error);
      }
    }
  };
  
  const handleShare = async () => {
    const shareData = {
        title: t('appName'),
        text: t('profile.share.text'),
        url: window.location.href,
    };
    if (navigator.share) {
        await navigator.share(shareData);
    } else {
        navigator.clipboard.writeText(shareData.url).then(() => {
            setShareStatus('copied');
            setTimeout(() => setShareStatus('idle'), 2000);
        });
    }
  };

  const handleInstallClick = async () => {
    if (!installPromptEvent) return;
    installPromptEvent.prompt();
    const { outcome } = await installPromptEvent.userChoice;
    if (outcome === 'accepted') setInstallPromptEvent(null);
    setShowInstallPrompt(false);
  };

  const handleDismissIOSPrompt = () => {
    localStorage.setItem('dismissedIOSInstallPrompt', 'true');
    setShowIOSInstallPrompt(false);
  };

  const handleCloseOnboarding = () => {
    localStorage.setItem('cidadao_alerta_onboarded', 'true');
    setShowOnboarding(false);
  };
  
  const handleCopyIban = () => {
    const iban = t('profile.developer.iban');
    navigator.clipboard.writeText(iban).then(() => {
        setIbanCopied(true);
        setTimeout(() => setIbanCopied(false), 2000);
    });
  };

  const handleCopyMulticaixa = () => {
    const number = t('profile.developer.multicaixaNumber');
    navigator.clipboard.writeText(number).then(() => {
        setMulticaixaCopied(true);
        setTimeout(() => setMulticaixaCopied(false), 2000);
    });
  };

  const renderNotificationUI = () => {
    switch(notificationPermissionStatus) {
      case 'granted':
        return <p className="text-sm text-emerald-700 dark:text-emerald-400"><i className="fa-solid fa-check-circle mr-2"></i>{t('profile.notifications.active')}</p>;
      case 'denied':
        return <p className="text-sm text-red-700 dark:text-red-400"><i className="fa-solid fa-times-circle mr-2"></i>{t('profile.notifications.blocked')}</p>;
      default:
        return <button onClick={handleNotificationPermission} className="w-full py-3 px-4 bg-blue-600 text-white rounded-xl font-bold text-sm hover:bg-blue-700 transition-colors"><i className="fa-solid fa-bell mr-2"></i> {t('profile.notifications.activate')}</button>;
    }
  };
  
  return (
    <div className="min-h-screen pb-24 flex flex-col">
      <header className="bg-blue-700 text-white pt-10 pb-20 px-6 rounded-b-[40px] relative overflow-hidden shadow-2xl">
        <div className="absolute top-0 left-0 w-full h-full opacity-10 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]"></div>
        <div className="relative z-10 flex justify-between items-center">
          <div className="flex items-center gap-3">
             <AppLogo className="h-8 w-8" />
            <div>
              <h1 className="text-2xl font-black tracking-tight">{t('appName')}</h1>
              <p className="text-blue-100 text-sm">{getGreeting()}</p>
            </div>
          </div>
          <div className="w-10 h-10 rounded-full bg-blue-500/50 flex items-center justify-center border border-white/20">
            <i className="fa-solid fa-bell"></i>
          </div>
        </div>
      </header>

      <main className="flex-1 px-6 -mt-12 relative z-20 space-y-8">
        {activeTab === 'home' && (
          <>
            <section>
              <h2 className="text-slate-900 dark:text-slate-100 font-bold mb-4 flex items-center"><span className="w-1.5 h-6 bg-red-600 rounded-full mr-2"></span>{t('home.emergencyTitle')}</h2>
              <div className="grid grid-cols-2 gap-4">
                <EmergencyButton label={t('emergencyButtons.police')} number="113" icon="fa-shield" color="bg-blue-600" />
                <EmergencyButton label={t('emergencyButtons.firefighters')} number="115" icon="fa-fire" color="bg-red-600" />
                <EmergencyButton label={t('emergencyButtons.medical')} number="112" icon="fa-plus" color="bg-emerald-600" />
                <EmergencyButton label={t('emergencyButtons.sosWoman')} number="111" icon="fa-person-dress" color="bg-pink-600" />
              </div>
            </section>
            <section>
              <h2 className="text-slate-900 dark:text-slate-100 font-bold mb-4 flex items-center"><span className="w-1.5 h-6 bg-blue-600 rounded-full mr-2"></span>{t('home.reportTitle')}</h2>
              <div className="space-y-3">
                {AGENCIES.map(agency => <AgencyCard key={agency.id} agency={agency} onClick={setSelectedAgency} />)}
              </div>
            </section>
            <section className="bg-indigo-50 dark:bg-indigo-900/30 p-6 rounded-3xl border border-indigo-100 dark:border-indigo-800/50">
               <div className="flex items-center mb-3">
                 <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white mr-3"><i className="fa-solid fa-hand-holding-heart"></i></div>
                 <h3 className="font-bold text-indigo-900 dark:text-indigo-200 leading-tight">{t('home.civicBox.title')}</h3>
               </div>
               <p className="text-indigo-800/80 dark:text-indigo-300/80 text-sm mb-4 leading-relaxed">{t('home.civicBox.text')}</p>
               <button onClick={() => setIsGuideOpen(true)} className="w-full py-3 bg-white dark:bg-slate-700 border border-indigo-200 dark:border-slate-600 text-indigo-700 dark:text-indigo-200 rounded-xl font-bold text-sm hover:bg-indigo-100 dark:hover:bg-slate-600 transition-colors">{t('home.civicBox.button')}</button>
            </section>
          </>
        )}
        {activeTab === 'history' && (
          <section>
            <h2 className="text-slate-900 dark:text-slate-100 font-bold mb-4">{t('history.title')}</h2>
            {isLoading ? (
                <div className="text-center py-10">
                    <div className="w-8 h-8 border-2 border-slate-200 dark:border-slate-700 border-t-blue-600 rounded-full animate-spin mx-auto"></div>
                    <p className="text-sm text-slate-500 dark:text-slate-400 mt-4">{t('history.loading')}</p>
                </div>
            ) : reports.length === 0 ? (
              <div className="bg-white dark:bg-slate-800 p-10 rounded-2xl text-center border-2 border-dashed border-slate-200 dark:border-slate-700">
                <i className="fa-solid fa-folder-open text-4xl text-slate-300 dark:text-slate-600 mb-4"></i>
                <p className="text-slate-500 dark:text-slate-400 mb-6">{t('history.empty')}</p>
                <button 
                  onClick={() => setActiveTab('home')}
                  className="py-3 px-6 bg-blue-600 text-white rounded-xl font-bold shadow-lg shadow-blue-200 dark:shadow-blue-900/50 active:scale-95 transition-all"
                >
                  {t('history.emptyButton')}
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                {reports.map(report => (
                  <ReportItem 
                    key={report.id} 
                    report={report} 
                    onClick={() => setViewingReport(report)}
                  />
                ))}
              </div>
            )}
          </section>
        )}
        {activeTab === 'profile' && (
          <section className="space-y-6">
            <div className="flex flex-col items-center text-center">
              <div className="w-24 h-24 rounded-full bg-slate-200 dark:bg-slate-700 border-4 border-white dark:border-slate-800 shadow-xl flex items-center justify-center text-slate-400 text-4xl mb-4 overflow-hidden">
                 <AppIcon className="w-full h-full" />
              </div>
              <h3 className="font-bold text-xl">{t('profile.anonymousUser')}</h3>
              <p className="text-slate-500 dark:text-slate-400 text-sm">{t('profile.protectedIdentity')}</p>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-blue-50 dark:bg-blue-900/30 p-4 rounded-2xl text-center border border-blue-100 dark:border-blue-800/50"><div className="text-2xl font-black text-blue-700 dark:text-blue-300">{reports.length}</div><div className="text-[10px] text-blue-600 dark:text-blue-400 font-bold uppercase">{t('profile.reports')}</div></div>
              <div className="bg-emerald-50 dark:bg-emerald-900/30 p-4 rounded-2xl text-center border border-emerald-100 dark:border-emerald-800/50"><div className="text-2xl font-black text-emerald-700 dark:text-emerald-300">100%</div><div className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold uppercase">{t('profile.privacy')}</div></div>
            </div>
            
            {showIOSInstallPrompt && <IOSInstallPrompt onClose={handleDismissIOSPrompt} />}
            
            <Suspense fallback={null}><AdminDashboardCard /></Suspense>

            <div className="bg-white dark:bg-slate-800 rounded-3xl p-6 border border-slate-200 dark:border-slate-700 text-left">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center">
                    <div className="w-10 h-10 bg-slate-100 dark:bg-slate-700 rounded-xl flex items-center justify-center text-slate-500 dark:text-slate-300 mr-4">
                        <i className="fa-solid fa-palette"></i>
                    </div>
                    <div>
                        <h4 className="font-bold text-slate-800 dark:text-slate-100">{t('profile.theme.title')}</h4>
                        <p className="text-xs text-slate-500 dark:text-slate-400">{t('profile.theme.description')}</p>
                    </div>
                  </div>
                   <ThemeToggle />
                </div>
            </div>

            <div className="bg-white dark:bg-slate-800 rounded-3xl p-6 border border-slate-200 dark:border-slate-700 text-left">
                <div className="flex items-center mb-4">
                    <div className="w-10 h-10 bg-slate-100 dark:bg-slate-700 rounded-xl flex items-center justify-center text-slate-500 dark:text-slate-300 mr-4">
                        <i className="fa-solid fa-language"></i>
                    </div>
                    <div>
                        <h4 className="font-bold text-slate-800 dark:text-slate-100">{t('profile.language.title')}</h4>
                        <p className="text-xs text-slate-500 dark:text-slate-400">{t('profile.language.description')}</p>
                    </div>
                </div>
                <div className="grid grid-cols-2 gap-2 mt-4">
                  {(Object.keys(LANGUAGES) as Language[]).map(lang => (
                    <button key={lang} onClick={() => setLanguage(lang)} className={`py-3 px-2 rounded-lg font-semibold text-sm transition-all ${language === lang ? 'bg-blue-600 text-white shadow-md' : 'bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-600'}`}>
                      {LANGUAGES[lang]}
                    </button>
                  ))}
                </div>
            </div>
            
            <div className="bg-white dark:bg-slate-800 rounded-3xl p-6 border border-slate-200 dark:border-slate-700 text-left">
                <div className="flex items-center mb-4">
                    <div className="w-10 h-10 bg-slate-100 dark:bg-slate-700 rounded-xl flex items-center justify-center text-slate-500 dark:text-slate-300 mr-4">
                        <i className="fa-solid fa-database"></i>
                    </div>
                    <div>
                        <h4 className="font-bold text-slate-800 dark:text-slate-100">{t('profile.dataManagement.title')}</h4>
                        <p className="text-xs text-slate-500 dark:text-slate-400">{t('profile.dataManagement.description')}</p>
                    </div>
                </div>
                <div className="flex gap-4 mt-4">
                    <button onClick={handleExportData} className="flex-1 flex flex-col items-center justify-center p-4 bg-slate-100 dark:bg-slate-700 rounded-xl hover:bg-slate-200 dark:hover:bg-slate-600 transition-colors">
                        <i className="fa-solid fa-download text-2xl text-slate-600 dark:text-slate-300 mb-2"></i>
                        <span className="text-sm font-semibold text-slate-800 dark:text-slate-200">{t('profile.dataManagement.export')}</span>
                    </button>
                    <button onClick={() => importFileRef.current?.click()} className="flex-1 flex flex-col items-center justify-center p-4 bg-slate-100 dark:bg-slate-700 rounded-xl hover:bg-slate-200 dark:hover:bg-slate-600 transition-colors">
                        <i className="fa-solid fa-file-import text-2xl text-slate-600 dark:text-slate-300 mb-2"></i>
                        <span className="text-sm font-semibold text-slate-800 dark:text-slate-200">{t('profile.dataManagement.import')}</span>
                    </button>
                    <input type="file" ref={importFileRef} onChange={handleImportData} className="hidden" accept=".json,application/json" />
                </div>
                <p className="text-xs text-slate-400 dark:text-slate-500 mt-3 text-center">{t('profile.dataManagement.info')}</p>
            </div>
            
            <div className="bg-white dark:bg-slate-800 rounded-3xl p-6 border border-slate-200 dark:border-slate-700 text-left">
                <div className="flex items-center mb-4">
                    <div className="w-10 h-10 bg-slate-100 dark:bg-slate-700 rounded-xl flex items-center justify-center text-slate-500 dark:text-slate-300 mr-4">
                        <i className="fa-solid fa-scale-balanced"></i>
                    </div>
                    <div>
                        <h4 className="font-bold text-slate-800 dark:text-slate-100">{t('profile.legal.title')}</h4>
                        <p className="text-xs text-slate-500 dark:text-slate-400">{t('profile.legal.description')}</p>
                    </div>
                </div>
                <div className="space-y-2 mt-4">
                    <button onClick={() => setIsTermsOpen(true)} className="w-full text-left p-3 bg-slate-100 dark:bg-slate-700 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-600 transition-colors text-sm font-semibold text-slate-700 dark:text-slate-200">
                      <i className="fa-solid fa-file-contract w-6 text-center mr-2 text-slate-500 dark:text-slate-400"></i>
                      {t('profile.legal.termsButton')}
                    </button>
                    <button onClick={() => setIsPrivacyOpen(true)} className="w-full text-left p-3 bg-slate-100 dark:bg-slate-700 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-600 transition-colors text-sm font-semibold text-slate-700 dark:text-slate-200">
                      <i className="fa-solid fa-user-shield w-6 text-center mr-2 text-slate-500 dark:text-slate-400"></i>
                      {t('profile.legal.privacyButton')}
                    </button>
                </div>
            </div>

            <div className="bg-white dark:bg-slate-800 rounded-3xl p-6 border border-slate-200 dark:border-slate-700 text-center">
                <h4 className="font-bold text-slate-800 dark:text-slate-100 mb-2">{t('profile.share.title')}</h4>
                <p className="text-sm text-slate-600 dark:text-slate-300 mb-4">{t('profile.share.description')}</p>
                <div className="flex gap-3">
                    <button onClick={handleShare} disabled={shareStatus === 'copied'} className={`flex-1 py-3 px-4 rounded-xl font-bold text-sm transition-colors ${shareStatus === 'copied' ? 'bg-emerald-600 text-white' : 'bg-indigo-600 text-white hover:bg-indigo-700 active:scale-95'}`}>
                        <i className={`fa-solid ${shareStatus === 'copied' ? 'fa-check' : 'fa-share-nodes'} mr-2`}></i>
                        {shareStatus === 'copied' ? t('profile.share.copied') : t('profile.share.button')}
                    </button>
                    <button onClick={() => setIsQrModalOpen(true)} className="py-3 px-4 rounded-xl font-bold text-sm bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200 hover:bg-slate-300 dark:hover:bg-slate-600 transition-colors active:scale-95" aria-label={t('profile.share.showQrButton')}>
                        <i className="fa-solid fa-qrcode"></i>
                    </button>
                </div>
            </div>
            <div className="bg-white dark:bg-slate-800 rounded-3xl p-6 border border-slate-200 dark:border-slate-700 text-center">
              <h4 className="font-bold text-slate-800 dark:text-slate-100 mb-2">{t('profile.notifications.title')}</h4>
              <p className="text-sm text-slate-600 dark:text-slate-300 mb-4">{t('profile.notifications.description')}</p>
              {renderNotificationUI()}
            </div>
            <div className="bg-white dark:bg-slate-800 rounded-3xl p-6 border border-slate-200 dark:border-slate-700 text-left">
              <h4 className="font-bold text-slate-800 dark:text-slate-100 mb-2 text-center">{t('profile.support.title')}</h4>
              <div className="space-y-3">
                <a href="mailto:eduardonex50@gmail.com" className="w-full flex items-center justify-center py-3 px-4 bg-indigo-600 text-white rounded-xl font-bold text-sm hover:bg-indigo-700 transition-colors"><i className="fa-solid fa-envelope mr-2"></i> {t('profile.support.emailButton')}</a>
              </div>
            </div>
            
            <div className="bg-white dark:bg-slate-800 rounded-3xl p-6 border border-slate-200 dark:border-slate-700 text-center">
              <i className="fa-solid fa-code text-2xl text-indigo-500 mb-3"></i>
              <h4 className="font-bold text-slate-800 dark:text-slate-100 mb-1">{t('profile.developer.title')}</h4>
              <p className="font-bold text-slate-700 dark:text-slate-200">{t('profile.developer.name')}</p>
              <div className="mt-4 pt-4 border-t border-slate-200 dark:border-slate-700">
                <h5 className="text-sm font-bold text-indigo-800 dark:text-indigo-300">{t('profile.developer.supportProject')}</h5>
                <div className="mt-2 text-xs bg-indigo-50 dark:bg-indigo-900/30 p-3 rounded-lg text-left">
                    <p className="font-semibold text-indigo-700 dark:text-indigo-200">{t('profile.developer.beneficiary')}: <span className="font-normal">{t('profile.developer.name')}</span></p>
                    <p className="font-semibold text-indigo-700 dark:text-indigo-200">IBAN: <span className="font-normal">{t('profile.developer.iban')}</span></p>
                </div>
                 <button 
                    onClick={handleCopyIban}
                    disabled={ibanCopied}
                    className="mt-3 w-full py-2 px-4 bg-indigo-500 text-white rounded-lg font-semibold text-xs hover:bg-indigo-600 transition-colors disabled:bg-emerald-500"
                >
                    <i className={`fa-solid ${ibanCopied ? 'fa-check' : 'fa-copy'} mr-2`}></i>
                    {ibanCopied ? t('profile.developer.ibanCopied') : t('profile.developer.copyIban')}
                 </button>

                 <div className="mt-4 text-xs bg-rose-50 dark:bg-rose-900/30 p-3 rounded-lg text-left">
                    <p className="font-semibold text-rose-700 dark:text-rose-200">{t('profile.developer.supportViaMulticaixa')}</p>
                    <p className="font-semibold text-rose-700 dark:text-rose-200 mt-1">Número: <span className="font-normal text-lg tracking-wider">{t('profile.developer.multicaixaNumber')}</span></p>
                </div>
                 <button 
                    onClick={handleCopyMulticaixa}
                    disabled={multicaixaCopied}
                    className="mt-3 w-full py-2 px-4 bg-rose-500 text-white rounded-lg font-semibold text-xs hover:bg-rose-600 transition-colors disabled:bg-emerald-500"
                >
                    <i className={`fa-solid ${multicaixaCopied ? 'fa-check' : 'fa-copy'} mr-2`}></i>
                    {multicaixaCopied ? t('profile.developer.numberCopied') : t('profile.developer.copyNumber')}
                 </button>
              </div>
            </div>
          </section>
        )}
      </main>
      <Suspense fallback={null}><AIChatBot /></Suspense>
      <nav className="fixed bottom-0 left-0 right-0 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-700 flex justify-around items-start z-40 shadow-[0_-5px_25px_rgba(0,0,0,0.08)]">
        {navItems.map(item => (<button key={item.id} onClick={() => setActiveTab(item.id as any)} className={`flex-1 flex flex-col items-center pt-3 pb-2 transition-colors ${activeTab === item.id ? 'text-blue-600 dark:text-blue-400' : 'text-slate-500 dark:text-slate-400 hover:text-blue-500 dark:hover:text-blue-400'}`}><div className="relative w-full flex justify-center"><i className={`fa-solid ${item.icon} text-xl`}></i>{activeTab === item.id && <span className="absolute -bottom-2.5 h-1.5 w-1.5 bg-blue-600 dark:bg-blue-400 rounded-full"></span>}</div><span className="text-[10px] font-bold uppercase mt-1">{item.label}</span></button>))}
      </nav>
      <Suspense fallback={<Spinner />}>
        {showOnboarding && <OnboardingModal onClose={handleCloseOnboarding} onOpenTerms={() => setIsTermsOpen(true)} onOpenPrivacy={() => setIsPrivacyOpen(true)} />}
        {selectedAgency && <ReportForm agency={selectedAgency.id} onClose={() => setSelectedAgency(null)} onSubmit={handleReportSubmit} />}
        {successInfo && (
          <SuccessModal 
            title={successInfo.title}
            message={successInfo.message}
            onClose={() => setSuccessInfo(null)}
            onShare={successInfo.onShare}
            report={successInfo.report}
          />
        )}
        {viewingReport && <ReportDetailModal report={viewingReport} onClose={() => setViewingReport(null)} />}
        {isGuideOpen && <CitizenGuideModal onClose={() => setIsGuideOpen(false)} />}
        {isQrModalOpen && <QRCodeModal onClose={() => setIsQrModalOpen(false)} url={window.location.href} />}
        {isTermsOpen && <LegalModal title={t('legal.terms.title')} onClose={() => setIsTermsOpen(false)}>{t('legal.terms.content')}</LegalModal>}
        {isPrivacyOpen && <LegalModal title={t('legal.privacy.title')} onClose={() => setIsPrivacyOpen(false)}>{t('legal.privacy.content')}</LegalModal>}
      </Suspense>
      {installPromptEvent && showInstallPrompt && <InstallPWA onInstall={handleInstallClick} onClose={() => setShowInstallPrompt(false)} />}
      {showUpdatePrompt && <UpdatePrompt onUpdate={handleUpdateApp} />}
    </div>
  );
};

export default App;
